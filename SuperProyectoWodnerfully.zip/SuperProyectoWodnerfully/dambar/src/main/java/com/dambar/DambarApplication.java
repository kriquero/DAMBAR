package com.dambar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DambarApplication {

	public static void main(String[] args) {
		SpringApplication.run(DambarApplication.class, args);
	}

}
