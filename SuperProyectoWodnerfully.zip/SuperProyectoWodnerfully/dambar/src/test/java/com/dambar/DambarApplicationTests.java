package com.dambar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DambarApplicationTests {

	@Test
	void contextLoads() {
	}

}
